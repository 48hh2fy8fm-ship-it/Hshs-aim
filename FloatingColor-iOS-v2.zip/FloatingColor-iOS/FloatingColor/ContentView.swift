import SwiftUI

struct ContentView: View {
    @State private var selectedTab = 0
    @State private var selectedColor = Color(red: 0.48, green: 0.08, blue: 0.85)
    @State private var overlayEnabled = true
    @State private var securityEnabled = false
    @State private var aimEnabled = true
    @State private var visualEnabled = true
    @State private var opacity: Double = 0.82
    @State private var showColorPicker = false

    private let tabs = ["VISUAL", "AIM", "SECURITY", "SETTINGS"]

    var body: some View {
        ZStack {
            Image("Background")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .overlay(Color.black.opacity(0.18).ignoresSafeArea())

            VStack(spacing: 0) {
                header
                tabBar
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 14) {
                        if selectedTab == 0 { visualPanel }
                        if selectedTab == 1 { aimPanel }
                        if selectedTab == 2 { securityPanel }
                        if selectedTab == 3 { settingsPanel }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 16)
                }
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showColorPicker) {
            ColorPickerSheet(color: $selectedColor)
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image("Skull")
                .resizable().scaledToFit()
                .frame(width: 42, height: 42)
                .clipShape(RoundedRectangle(cornerRadius: 8))
            VStack(alignment: .leading, spacing: 1) {
                Text("FLOATING COLOR")
                    .font(.system(size: 21, weight: .heavy, design: .rounded))
                Text("OVERLAY CONTROL")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .opacity(0.72)
            }
            Spacer()
            Toggle("", isOn: $overlayEnabled)
                .labelsHidden()
                .tint(selectedColor)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 13)
        .background(.black.opacity(0.48))
    }

    private var tabBar: some View {
        HStack(spacing: 0) {
            ForEach(Array(tabs.enumerated()), id: \.offset) { index, title in
                Button { withAnimation(.easeInOut(duration: 0.18)) { selectedTab = index } } label: {
                    VStack(spacing: 7) {
                        Image(systemName: icon(for: index))
                            .font(.system(size: 15, weight: .bold))
                        Text(title)
                            .font(.system(size: 8, weight: .black, design: .monospaced))
                            .lineLimit(1)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .foregroundStyle(index == selectedTab ? selectedColor : .white.opacity(0.65))
                }
            }
        }
        .background(.black.opacity(0.60))
        .overlay(alignment: .bottom) {
            GeometryReader { proxy in
                Rectangle()
                    .fill(selectedColor)
                    .frame(width: proxy.size.width / 4, height: 2)
                    .offset(x: proxy.size.width / 4 * CGFloat(selectedTab))
            }
            .frame(height: 2)
        }
    }

    private var visualPanel: some View {
        VStack(spacing: 12) {
            sectionTitle("VISUAL", subtitle: "COLOR / OVERLAY")
            actionRow(title: "COLOR", subtitle: "Choose overlay color", icon: "paintpalette.fill") {
                showColorPicker = true
            }
            HStack(spacing: 12) {
                Circle().fill(selectedColor).frame(width: 44, height: 44)
                    .overlay(Circle().stroke(.white.opacity(0.7), lineWidth: 2))
                VStack(alignment: .leading, spacing: 5) {
                    Text("ACTIVE COLOR").font(.system(size: 10, weight: .black, design: .monospaced))
                    Text("Custom overlay tint").font(.system(size: 11)).opacity(0.62)
                }
                Spacer()
            }
            .padding(12).panelStyle()
            toggleRow("Visual overlay", "Show the floating visual layer", isOn: $visualEnabled)
            sliderRow("Opacity", value: $opacity)
        }
    }

    private var aimPanel: some View {
        VStack(spacing: 12) {
            sectionTitle("AIM", subtitle: "FLOATING CONTROL")
            toggleRow("Aim mode", "Enable the aiming overlay", isOn: $aimEnabled)
            actionRow(title: "POSITION", subtitle: "Floating control position", icon: "scope") { }
            actionRow(title: "SIZE", subtitle: "Adjust overlay scale", icon: "arrow.up.left.and.arrow.down.right") { }
        }
    }

    private var securityPanel: some View {
        VStack(spacing: 12) {
            sectionTitle("SECURITY", subtitle: "PROTECTION")
            toggleRow("Security mode", "Protect overlay settings", isOn: $securityEnabled)
            actionRow(title: "LOCK", subtitle: "Lock current configuration", icon: "lock.fill") { }
            actionRow(title: "RESET", subtitle: "Restore default configuration", icon: "arrow.counterclockwise") { }
        }
    }

    private var settingsPanel: some View {
        VStack(spacing: 12) {
            sectionTitle("SETTINGS", subtitle: "APP CONFIGURATION")
            actionRow(title: "FLOATING WINDOW", subtitle: overlayEnabled ? "Enabled" : "Disabled", icon: "rectangle.on.rectangle") { overlayEnabled.toggle() }
            actionRow(title: "COLOR", subtitle: "Open color picker", icon: "paintbrush.fill") { showColorPicker = true }
            actionRow(title: "ABOUT", subtitle: "Floating Color iOS recreation", icon: "info.circle.fill") { }
        }
    }

    private func sectionTitle(_ title: String, subtitle: String) -> some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.system(size: 22, weight: .black, design: .rounded))
                Text(subtitle).font(.system(size: 9, weight: .bold, design: .monospaced)).opacity(0.55)
            }
            Spacer()
        }
        .padding(.top, 4)
    }

    private func actionRow(title: String, subtitle: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon).font(.system(size: 16, weight: .bold)).frame(width: 28)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.system(size: 12, weight: .black, design: .monospaced))
                    Text(subtitle).font(.system(size: 10)).opacity(0.55)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.system(size: 11, weight: .bold)).opacity(0.5)
            }
            .foregroundStyle(.white)
            .padding(13)
            .panelStyle()
        }
        .buttonStyle(.plain)
    }

    private func toggleRow(_ title: String, _ subtitle: String, isOn: Binding<Bool>) -> some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 12, weight: .black, design: .monospaced))
                Text(subtitle).font(.system(size: 10)).opacity(0.55)
            }
            Spacer()
            Toggle("", isOn: isOn).labelsHidden().tint(selectedColor)
        }
        .padding(13).panelStyle()
    }

    private func sliderRow(_ title: String, value: Binding<Double>) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack { Text(title).font(.system(size: 11, weight: .black, design: .monospaced)); Spacer(); Text("\(Int(value.wrappedValue * 100))%").font(.system(size: 10, weight: .bold, design: .monospaced)).opacity(0.7) }
            Slider(value: value, in: 0...1).tint(selectedColor)
        }
        .padding(13).panelStyle()
    }

    private func icon(for index: Int) -> String {
        ["eye.fill", "scope", "lock.fill", "gearshape.fill"][index]
    }
}

private struct ColorPickerSheet: View {
    @Binding var color: Color
    var body: some View {
        VStack(spacing: 20) {
            Text("Select a Color").font(.title3.weight(.heavy))
            ColorPicker("Overlay color", selection: $color, supportsOpacity: true)
                .padding(.horizontal)
            HStack { ColorSwatch(.purple, color: $color); ColorSwatch(.red, color: $color); ColorSwatch(.orange, color: $color); ColorSwatch(.cyan, color: $color); ColorSwatch(.green, color: $color) }
            Spacer()
        }
        .padding(.top, 22)
        .padding(.horizontal, 16)
    }
}

private struct ColorSwatch: View {
    let base: Color
    @Binding var color: Color
    var body: some View {
        Button { color = base } label: { Circle().fill(base).frame(width: 42, height: 42).overlay(Circle().stroke(.primary.opacity(0.18), lineWidth: 1)) }
    }
}

private extension View {
    func panelStyle() -> some View {
        self.background(.black.opacity(0.55), in: RoundedRectangle(cornerRadius: 9))
            .overlay(RoundedRectangle(cornerRadius: 9).stroke(.white.opacity(0.09), lineWidth: 1))
    }
}
