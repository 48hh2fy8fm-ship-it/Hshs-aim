import SwiftUI

@main
struct FloatingColorApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
