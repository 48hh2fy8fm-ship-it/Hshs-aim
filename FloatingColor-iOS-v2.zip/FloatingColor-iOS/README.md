# Floating Color — iOS recreation

This is an Xcode/SwiftUI recreation based on the supplied Android APK resources and layout names. The UI now mirrors the dark purple artwork, skull branding, Visual/Aim/Security/Settings tabs, color picker, overlay toggle, opacity, and floating-control style.

## About source code
The IPA/app bundle produced by Xcode contains compiled Swift/SwiftUI binaries and resources; the `.swift` source files are not copied into the IPA. This package contains source only because it is an Xcode project used to build the app.

## Build
Open `FloatingColor.xcodeproj` on a Mac with Xcode, select an iPhone target, then Archive and Export the app. Apple signing is required for a real installable IPA.
